package com.example.jobhunter.config;
import java.util.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
@Component
@ConfigurationProperties(prefix="jobhunter")
public class JobHunterProperties {
 private long scanIntervalMs=21600000; private int minMatchScore=60;
 private List<String> keywords=new ArrayList<>(), targetTitles=new ArrayList<>(), preferredLocations=new ArrayList<>(),
 greenhouseBoards=new ArrayList<>(), leverSites=new ArrayList<>(), ashbyBoards=new ArrayList<>(), rssFeeds=new ArrayList<>();
 private boolean enableRemotive=true, enableRemoteok=true;
 public long getScanIntervalMs(){return scanIntervalMs;} public void setScanIntervalMs(long v){scanIntervalMs=v;}
 public int getMinMatchScore(){return minMatchScore;} public void setMinMatchScore(int v){minMatchScore=v;}
 public List<String> getKeywords(){return keywords;} public void setKeywords(List<String> v){keywords=v;}
 public List<String> getTargetTitles(){return targetTitles;} public void setTargetTitles(List<String> v){targetTitles=v;}
 public List<String> getPreferredLocations(){return preferredLocations;} public void setPreferredLocations(List<String> v){preferredLocations=v;}
 public List<String> getGreenhouseBoards(){return greenhouseBoards;} public void setGreenhouseBoards(List<String> v){greenhouseBoards=v;}
 public List<String> getLeverSites(){return leverSites;} public void setLeverSites(List<String> v){leverSites=v;}
 public List<String> getAshbyBoards(){return ashbyBoards;} public void setAshbyBoards(List<String> v){ashbyBoards=v;}
 public List<String> getRssFeeds(){return rssFeeds;} public void setRssFeeds(List<String> v){rssFeeds=v;}
 public boolean isEnableRemotive(){return enableRemotive;} public void setEnableRemotive(boolean v){enableRemotive=v;}
 public boolean isEnableRemoteok(){return enableRemoteok;} public void setEnableRemoteok(boolean v){enableRemoteok=v;}
}