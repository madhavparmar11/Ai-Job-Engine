package com.example.jobhunter.web;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/files")
public class GeneratedFileController {
    private static final Pattern SAFE_ID = Pattern.compile("[A-Za-z0-9][A-Za-z0-9_-]{0,99}");

    @GetMapping("/download")
    public ResponseEntity<Resource> download(@RequestParam String source,
                                              @RequestParam String sourceId,
                                              @RequestParam String type) throws Exception {
        if (!valid(source) || !valid(sourceId) || !("resume".equals(type) || "cover-letter".equals(type)))
            return ResponseEntity.notFound().build();
        Path root = Path.of("data", "generated").toAbsolutePath().normalize();
        if (!Files.isDirectory(root)) return ResponseEntity.notFound().build();
        Path file = root.resolve(source).resolve(sourceId).resolve(
                ("resume".equals(type) ? "tailored-resume" : "cover-letter") + ".docx").normalize();
        if (!file.startsWith(root) || !Files.isRegularFile(file) || !file.toRealPath().startsWith(root.toRealPath()))
            return ResponseEntity.notFound().build();
        String filename = file.getFileName().toString();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(filename).build().toString())
                .body(new FileSystemResource(file));
    }

    private boolean valid(String value) { return value != null && SAFE_ID.matcher(value).matches(); }
}
