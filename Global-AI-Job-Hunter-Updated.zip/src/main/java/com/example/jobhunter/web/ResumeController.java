package com.example.jobhunter.web;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.example.jobhunter.service.ResumeTextExtractor;

@RestController
@RequestMapping("/api/resume")
public class ResumeController {
    private static final long MAX_SIZE = 10L * 1024 * 1024;
    private final ResumeTextExtractor extractor;
    public ResumeController(ResumeTextExtractor extractor) { this.extractor = extractor; }

    @PostMapping(value="/upload", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    public String upload(@RequestParam("file") MultipartFile file) throws Exception {
        String original = file.getOriginalFilename() == null ? "" : file.getOriginalFilename();
        String name = Path.of(original.replace('\\', '/')).getFileName().toString().toLowerCase(Locale.ROOT);
        if (!(name.endsWith(".pdf") || name.endsWith(".docx"))) throw new IllegalArgumentException("Upload a PDF or DOCX file.");
        if (file.isEmpty() || file.getSize() > MAX_SIZE) throw new IllegalArgumentException("Resume must be non-empty and no larger than 10 MB.");

        Path dir = Path.of("data", "resume").toAbsolutePath().normalize();
        Files.createDirectories(dir);
        String extension = name.endsWith(".pdf") ? ".pdf" : ".docx";
        Path temp = Files.createTempFile(dir, "resume-upload-", extension);
        Path marker = dir.resolve("active-resume-format.txt");
        Path extractedFile = dir.resolve("master-resume-extracted.txt");
        Path target = dir.resolve("master-resume" + extension);
        Path other = dir.resolve(extension.equals(".pdf") ? "master-resume.docx" : "master-resume.pdf");
        Path markerStage = Files.createTempFile(dir, "active-resume-", ".tmp");
        Path extractedStage = Files.createTempFile(dir, "resume-text-", ".tmp");
        java.util.Map<Path, Path> backups = new java.util.LinkedHashMap<>();
        java.util.Set<Path> previouslyAbsent = new java.util.HashSet<>();
        boolean committed = false;
        boolean rollbackComplete = false;
        try {
            try (var in = file.getInputStream()) { Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING); }
            String extracted = extractor.extract(temp);
            if (extracted == null || extracted.isBlank()) throw new IllegalArgumentException("No readable text was found in the resume.");
            if (extracted.length() > 2_000_000) throw new IllegalArgumentException("Extracted resume text is too large.");
            Files.writeString(markerStage, extension);
            Files.writeString(extractedStage, extracted);

            for (Path existing : java.util.List.of(target, other, marker, extractedFile)) {
                if (Files.exists(existing)) {
                    if (Files.isSymbolicLink(existing)) throw new IllegalArgumentException("Resume storage contains an unexpected symbolic link.");
                    Path backup = Files.createTempFile(dir, "resume-backup-", ".tmp");
                    Files.copy(existing, backup, StandardCopyOption.REPLACE_EXISTING);
                    backups.put(existing, backup);
                } else previouslyAbsent.add(existing);
            }
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            Files.move(markerStage, marker, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            Files.move(extractedStage, extractedFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            Files.deleteIfExists(other);
            committed = true;
            return "Resume uploaded and text extracted. Please review the extracted profile.";
        } catch (Exception failure) {
            Exception rollbackFailure = null;
            for (Path absent : previouslyAbsent) {
                try { Files.deleteIfExists(absent); }
                catch (Exception ex) { if (rollbackFailure == null) rollbackFailure = ex; else rollbackFailure.addSuppressed(ex); }
            }
            for (var entry : backups.entrySet()) {
                try {
                    Path backup = entry.getValue();
                    if (Files.exists(backup)) Files.move(backup, entry.getKey(), StandardCopyOption.REPLACE_EXISTING);
                    else throw new java.io.IOException("Required resume backup is missing: " + backup.getFileName());
                } catch (Exception ex) { if (rollbackFailure == null) rollbackFailure = ex; else rollbackFailure.addSuppressed(ex); }
            }
            rollbackComplete = rollbackFailure == null;
            if (rollbackFailure != null) {
                failure.addSuppressed(rollbackFailure);
                throw new IllegalStateException("Resume upload failed and rollback was incomplete. Preserve backup files in " + dir + " and inspect server logs.", failure);
            }
            throw failure;
        } finally {
            Files.deleteIfExists(temp);
            Files.deleteIfExists(markerStage);
            Files.deleteIfExists(extractedStage);
            // Never delete the only recovery copy after a failed rollback.
            if (committed || rollbackComplete) for (Path backup : backups.values()) Files.deleteIfExists(backup);
        }
    }
}
