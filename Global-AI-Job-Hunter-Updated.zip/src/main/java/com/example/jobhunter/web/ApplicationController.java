package com.example.jobhunter.web;

import com.example.jobhunter.service.ApplicationRepository;
import java.util.Map;
import java.util.Set;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {
    private static final Set<String> STATUSES = Set.of("SAVED", "APPLIED", "INTERVIEW", "OFFER", "REJECTED", "WITHDRAWN");
    private final ApplicationRepository repo;
    public ApplicationController(ApplicationRepository r) { repo=r; }
    @GetMapping public Object all(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="25") int size) {
        if (page < 0) throw new IllegalArgumentException("page must be zero or greater");
        var result = repo.findPage(page, size);
        return java.util.Map.of("items", result.items(), "totalElements", result.totalElements(), "page", result.page(), "size", result.size(), "totalPages", result.totalPages());
    }
    @PostMapping public String save(@RequestBody Map<String,String> body) {
        String source=body.get("source"), id=body.get("sourceId");
        if (source==null || id==null || source.isBlank() || id.isBlank()) throw new IllegalArgumentException("source and sourceId are required");
        if (source.length()>100 || id.length()>500) throw new IllegalArgumentException("source or sourceId is too long");
        String status=body.getOrDefault("status", "SAVED").toUpperCase(java.util.Locale.ROOT);
        if (!STATUSES.contains(status)) throw new IllegalArgumentException("Unsupported application status");
        String title=body.getOrDefault("title", id);
        if (title.length()>1000) throw new IllegalArgumentException("title is too long");
        repo.save(source, id, title, status);
        return "Job added to application tracker.";
    }
}
