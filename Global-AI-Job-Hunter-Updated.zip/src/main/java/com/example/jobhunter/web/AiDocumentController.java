package com.example.jobhunter.web;

import com.example.jobhunter.service.*;
import java.nio.file.Path;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class AiDocumentController {
    private final ProfileService profile;
    private final DocumentService docs;
    private final OpenAiService ai;
    public AiDocumentController(ProfileService p, DocumentService d, OpenAiService a) { profile=p; docs=d; ai=a; }

    @PostMapping("/profile/refresh")
    public String refresh() throws Exception {
        String text = profile.refreshFromUploadedResume();
        return "Profile text extracted (" + text.length() + " characters). Review it before generating documents.";
    }

    @GetMapping("/status")
    public Map<String,Object> status() { return Map.of("configured", ai.isConfigured(), "approvalRequired", true); }

    @PostMapping("/documents/{type}")
    public Map<String,String> generate(@PathVariable String type, @RequestBody Map<String,String> body) throws Exception {
        String profileText = profile.getProfile();
        if (profileText == null || profileText.isBlank()) throw new IllegalStateException("Upload a resume and refresh the profile first.");
        String source=body.get("source"), sourceId=body.get("sourceId"), description=body.get("jobDescription");
        if (source==null || sourceId==null || description==null || description.isBlank())
            throw new IllegalArgumentException("source, sourceId and a non-empty jobDescription are required.");
        if (description.length() > 50000) throw new IllegalArgumentException("Job description must be 50,000 characters or fewer.");
        Path path = switch(type) {
            case "resume" -> docs.createTailoredResume(source, sourceId, profileText, description);
            case "cover-letter" -> docs.createCoverLetter(source, sourceId, profileText, description);
            default -> throw new IllegalArgumentException("Supported types: resume, cover-letter");
        };
        return Map.of("status", "GENERATED_REQUIRES_REVIEW", "file", path.toString(),
                "downloadUrl", "/api/files/download?source=" + source + "&sourceId=" + sourceId + "&type=" + type);
    }
}
