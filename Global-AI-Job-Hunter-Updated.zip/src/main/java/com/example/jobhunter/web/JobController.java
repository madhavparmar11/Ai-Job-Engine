package com.example.jobhunter.web;

import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.service.JobRepository;
import com.example.jobhunter.service.ScanService;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class JobController {
    private final JobRepository repository;
    private final ScanService scanService;
    private final JobHunterProperties properties;
    public JobController(JobRepository repository, ScanService scanService, JobHunterProperties properties) {
        this.repository = repository; this.scanService = scanService; this.properties = properties;
    }
    @GetMapping("/health") public String health() { return "Global AI Job Hunter is running"; }
    @PostMapping("/scan") public String scan() { return scanService.scan(); }
    @GetMapping("/jobs") public Map<String,Object> jobs(
            @RequestParam(defaultValue="-1") int minScore,
            @RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="25") int size) {
        if (page < 0) throw new IllegalArgumentException("page must be zero or greater");
        int minimum = minScore < 0 ? properties.getMinMatchScore() : Math.min(100, minScore);
        JobRepository.Page<?> result = repository.findPage(minimum, page, size);
        return Map.of("items", result.items(), "totalElements", result.totalElements(), "page", result.page(), "size", result.size(), "totalPages", result.totalPages());
    }
}
