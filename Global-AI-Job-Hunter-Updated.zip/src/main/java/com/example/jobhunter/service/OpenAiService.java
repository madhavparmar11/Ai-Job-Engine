package com.example.jobhunter.service;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import java.net.http.HttpClient;
import java.time.Duration;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Server-side OpenAI Responses API adapter. API keys are read from environment,
 * never sent to browser code. Uses plain text output and validates required content locally.
 */
@Service
public class OpenAiService {
 private final String apiKey, model;
 private final RestClient client=RestClient.builder().baseUrl("https://api.openai.com/v1")
   .requestFactory(requestFactory()).build();
 private static JdkClientHttpRequestFactory requestFactory() {
  HttpClient httpClient=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
  JdkClientHttpRequestFactory factory=new JdkClientHttpRequestFactory(httpClient);
  factory.setReadTimeout(Duration.ofSeconds(60));
  return factory;
 }
 private final ObjectMapper mapper=new ObjectMapper();
 public OpenAiService(@Value("${openai.api-key:}") String key,@Value("${openai.model:gpt-5.2}") String model){
  this.apiKey=key; this.model=model;
 }
 public boolean isConfigured(){return apiKey!=null&&!apiKey.isBlank();}
 public String generate(String instructions,String input){
  if(!isConfigured()) throw new IllegalStateException("OpenAI is not configured. Set OPENAI_API_KEY on the server.");
  Map<String,Object> body=Map.of("model",model,"instructions",instructions,"input",input);
  JsonNode response=client.post().uri("/responses").contentType(MediaType.APPLICATION_JSON)
    .header("Authorization","Bearer "+apiKey).body(body).retrieve().body(JsonNode.class);
  if(response==null) throw new IllegalStateException("Empty AI response");
  String direct=response.path("output_text").asText("");
  if(!direct.isBlank()) return direct;
  StringBuilder text=new StringBuilder();
  for(JsonNode item:response.path("output")) for(JsonNode content:item.path("content"))
    if("output_text".equals(content.path("type").asText())) text.append(content.path("text").asText());
  if(text.isEmpty()) throw new IllegalStateException("AI returned no text output");
  return text.toString();
 }
}
