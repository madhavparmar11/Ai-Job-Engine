package com.example.jobhunter.service;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.springframework.stereotype.Service;

@Service
public class ResumeTextExtractor {
    public String extract(Path path) throws Exception {
        String name = path.getFileName().toString().toLowerCase(java.util.Locale.ROOT);
        String result;
        if (name.endsWith(".pdf")) {
            try (var doc = Loader.loadPDF(path.toFile())) { result = new PDFTextStripper().getText(doc); }
        } else if (name.endsWith(".docx")) {
            try (InputStream in = Files.newInputStream(path); XWPFDocument doc = new XWPFDocument(in)) {
                StringBuilder text = new StringBuilder();
                appendBody(doc, text);
                result = text.toString();
            }
        } else {
            throw new IllegalArgumentException("Unsupported resume format");
        }
        if (result == null || result.isBlank()) throw new IllegalArgumentException("No readable text found in the resume.");
        return result;
    }

    private void appendBody(org.apache.poi.xwpf.usermodel.IBody body, StringBuilder out) {
        for (IBodyElement element : body.getBodyElements()) {
            if (element instanceof XWPFParagraph paragraph) appendParagraph(paragraph, out);
            else if (element instanceof XWPFTable table) {
                for (var row : table.getRows()) for (XWPFTableCell cell : row.getTableCells()) appendBody(cell, out);
            }
        }
    }

    private void appendParagraph(XWPFParagraph paragraph, StringBuilder out) {
        String value = paragraph.getText();
        if (value != null && !value.isBlank()) out.append(value).append('\n');
    }
}
