package com.example.jobhunter.service;

import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.model.Job;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Component
public class Matcher {
    private final JobHunterProperties properties;
    private static final Pattern EXPERIENCE = Pattern.compile(
        "(?i)(?:(?:minimum\\s+of|at\\s+least|required\\s+|minimum\\s+)?)(\\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)(?:\\s*(?:-|–|to)\\s*(\\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten))?\\s*\\+?\\s*(?:years?|yrs?)\\s*(?:of\\s*)?(?:relevant\\s*)?(?:professional\\s*)?experience");
    private static final Pattern TOKEN = Pattern.compile("(?<![a-z0-9])%s(?![a-z0-9])", Pattern.CASE_INSENSITIVE);

    public Matcher(JobHunterProperties properties) { this.properties = properties; }

    public int score(Job job) {
        String title = clean(job.title()).toLowerCase(Locale.ROOT);
        String description = clean(job.description()).toLowerCase(Locale.ROOT);
        String location = clean(job.location()).toLowerCase(Locale.ROOT);
        String workplace = clean(job.workplaceType()).toLowerCase(Locale.ROOT);
        String text = title + " " + description;

        int skillScore = 0;
        if (containsTechnology(text, "java")) skillScore += 15;
        if (containsAny(text, "spring boot", "spring framework")) skillScore += 15;
        if (containsAny(text, "rest api", "restful", "rest apis")) skillScore += 7;
        if (containsAny(text, "sql", "mysql", "postgresql")) skillScore += 7;
        if (containsAny(text, "microservices", "microservice")) skillScore += 6;
        if (containsAny(text, "hibernate", "spring data jpa", "jpa")) skillScore += 5;

        int roleScore = 0;
        if (containsAny(title, "backend", "back-end")) roleScore += 10;
        if (containsAny(title, "java developer", "java engineer")) roleScore += 12;
        if (containsAny(title, "software engineer", "software developer")) roleScore += 7;
        if (containsAny(title, "full stack", "full-stack", "fullstack")) roleScore += 4;

        List<String> targets = safeList(properties.getTargetTitles());
        int titleBonus = targets.stream().filter(t -> title.contains(t.toLowerCase(Locale.ROOT))).findAny().isPresent() ? 8 : 0;
        List<String> keywords = safeList(properties.getKeywords());
        long keywordHits = keywords.stream().filter(k -> containsTechnology(text, k)).count();
        int extraScore = (int)Math.min(10, keywordHits * 2);

        int penalty = 0;
        if (containsAny(title, "principal", "director", "vice president", "head of engineering")) penalty += 45;
        else if (containsAny(title, "staff engineer", "senior", "lead engineer", "engineering manager")) penalty += 30;
        else if (containsAny(title, "architect")) penalty += 25;
        int years = extractRequiredYears(description);
        if (years > 2) penalty += Math.min(25, (years - 2) * 8);
        if (containsAny(text, "united states only", "us residents only", "must be authorized to work in the us", "must reside in the united states", "uk residents only", "must reside in the uk")) penalty += 20;
        if (containsAny(title, "devops engineer", "site reliability engineer", "network engineer", "security engineer", "infrastructure engineer")) penalty += 20;

        List<String> preferredLocations = safeList(properties.getPreferredLocations());
        boolean remoteMentioned = containsAny(text + " " + workplace, "remote", "work from home", "distributed team");
        boolean locationIsUnspecifiedRemote = location.equals("remote") || location.equals("work from home");
        if (!preferredLocations.isEmpty() && !location.isBlank() && !locationIsUnspecifiedRemote
                && preferredLocations.stream().noneMatch(loc -> location.contains(loc.toLowerCase(Locale.ROOT)))) penalty += 15;

        int remoteBonus = remoteMentioned ? 3 : 0;
        return Math.max(0, Math.min(100, skillScore + roleScore + extraScore + titleBonus + remoteBonus - penalty));
    }

    int extractRequiredYears(String text) {
        java.util.regex.Matcher matcher = EXPERIENCE.matcher(clean(text));
        int required = 0;
        while (matcher.find()) {
            int start = Math.max(0, matcher.start() - 65);
            int end = Math.min(text.length(), matcher.end() + 90);
            String context = text.substring(start, end).toLowerCase(Locale.ROOT);
            if (Pattern.compile("\\b(preferred|preferably|ideally|ideal|nice[- ]to[- ]have|a plus|bonus|would be ideal)\\b").matcher(context).find()) continue;
            int first = number(matcher.group(1));
            int second = matcher.group(2) == null ? first : number(matcher.group(2));
            required = Math.max(required, Math.max(first, second));
        }
        return required;
    }

    private int number(String value) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ignored) {
            return switch (value.toLowerCase(Locale.ROOT)) { case "one" -> 1; case "two" -> 2; case "three" -> 3; case "four" -> 4; case "five" -> 5; case "six" -> 6; case "seven" -> 7; case "eight" -> 8; case "nine" -> 9; case "ten" -> 10; default -> 0; };
        }
    }
    private boolean containsTechnology(String text, String term) {
        if (term == null || term.isBlank()) return false;
        return Pattern.compile(String.format(TOKEN.pattern(), Pattern.quote(term)), Pattern.CASE_INSENSITIVE).matcher(text).find();
    }
    private List<String> safeList(List<String> values) { return values == null ? List.of() : values.stream().filter(v -> v != null && !v.isBlank()).map(v -> v.trim()).toList(); }
    private boolean containsAny(String text, String... terms) { for (String term : terms) if (text.contains(term)) return true; return false; }
    private String clean(String value) { return value == null ? "" : value; }
}
