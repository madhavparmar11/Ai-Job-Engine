package com.example.jobhunter.service;

import com.example.jobhunter.model.ApplicationRecord;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ApplicationRepository {
    private final JdbcTemplate jdbc;
    public ApplicationRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }
    public void save(String source, String sourceId, String title, String status) {
        jdbc.update("MERGE INTO applications(source,source_id,title,status) KEY(source,source_id) VALUES(?,?,?,?)", source, sourceId, title, status);
    }
    public List<ApplicationRecord> all() { return findPage(0, 100).items(); }
    public JobRepository.Page<ApplicationRecord> findPage(int page, int size) {
        int safePage = Math.max(0, page), safeSize = Math.max(1, Math.min(100, size));
        long total = jdbc.queryForObject("SELECT COUNT(*) FROM applications", Long.class);
        List<ApplicationRecord> items = jdbc.query("SELECT id,source,source_id,title,status,notes,CAST(created_at AS VARCHAR) FROM applications ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (r,n)->new ApplicationRecord(r.getLong(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getString(7)), safeSize, (long)safePage * safeSize);
        return new JobRepository.Page<>(items, total, safePage, safeSize);
    }
}
