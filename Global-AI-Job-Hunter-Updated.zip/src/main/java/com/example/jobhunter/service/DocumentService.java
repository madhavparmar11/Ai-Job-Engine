package com.example.jobhunter.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.regex.Pattern;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.stereotype.Service;

/** Creates editable DOCX documents using only verified candidate facts. */
@Service
public class DocumentService {
    private static final Pattern SAFE_ID = Pattern.compile("[A-Za-z0-9][A-Za-z0-9_-]{0,99}");
    private final OpenAiService ai;

    public DocumentService(OpenAiService ai) { this.ai = ai; }

    public Path createTailoredResume(String source, String sourceId, String profile, String jobDescription) throws Exception {
        validateId(source, "source");
        validateId(sourceId, "sourceId");
        String content = ai.generate(
            "You are a careful resume editor. Rewrite a targeted resume using ONLY facts explicitly present in the candidate profile. Never invent employers, dates, titles, skills, metrics, certifications, education or achievements. Preserve factual meaning. Use ATS-friendly headings and concise bullets. Return plain text only.",
            "VERIFIED CANDIDATE PROFILE:\n" + profile + "\n\nJOB DESCRIPTION:\n" + jobDescription +
            "\n\nProduce a tailored resume. Emphasize relevant verified evidence and omit unsupported requirements.");
        return writeDocx("tailored-resume", source, sourceId, content);
    }

    public Path createCoverLetter(String source, String sourceId, String profile, String jobDescription) throws Exception {
        validateId(source, "source");
        validateId(sourceId, "sourceId");
        String content = ai.generate(
            "Write a concise professional cover letter based only on the verified candidate profile. Do not invent experience or claim skills not evidenced. Return plain text only.",
            "CANDIDATE PROFILE:\n" + profile + "\n\nJOB DESCRIPTION:\n" + jobDescription);
        return writeDocx("cover-letter", source, sourceId, content);
    }

    private Path writeDocx(String type, String source, String sourceId, String text) throws Exception {
        String safeSource = validateId(source, "source");
        String safeSourceId = validateId(sourceId, "sourceId");
        Path root = Path.of("data", "generated").toAbsolutePath().normalize();
        Path dir = root.resolve(safeSource).resolve(safeSourceId).normalize();
        if (!dir.startsWith(root)) throw new IllegalArgumentException("Invalid document destination");
        Files.createDirectories(dir);
        Path realRoot = root.toRealPath();
        Path realDir = dir.toRealPath();
        if (!realDir.startsWith(realRoot) || Files.isSymbolicLink(root) || Files.isSymbolicLink(dir)
                || Files.isSymbolicLink(root.resolve(safeSource)) || Files.isSymbolicLink(root.resolve(safeSource).resolve(safeSourceId))) {
            throw new IllegalArgumentException("Symbolic-link document destinations are not allowed");
        }
        Path target = dir.resolve(type + ".docx");
        if (Files.isSymbolicLink(target)) throw new IllegalArgumentException("Symbolic-link document targets are not allowed");
        Path temp = Files.createTempFile(dir, type + "-", ".tmp");
        boolean moved = false;
        try {
            try (XWPFDocument doc = new XWPFDocument()) {
                if (text != null) for (String line : text.split("\\R", -1)) doc.createParagraph().createRun().setText(line);
                try (var out = Files.newOutputStream(temp)) { doc.write(out); }
            }
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            moved = true;
            return target;
        } finally {
            if (!moved) Files.deleteIfExists(temp);
        }
    }

    private String validateId(String value, String field) {
        if (value == null || !SAFE_ID.matcher(value).matches())
            throw new IllegalArgumentException("Invalid " + field + ": use 1-100 letters, numbers, underscores or hyphens.");
        return value;
    }
}
