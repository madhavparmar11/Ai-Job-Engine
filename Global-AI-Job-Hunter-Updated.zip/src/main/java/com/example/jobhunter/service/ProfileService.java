package com.example.jobhunter.service;

import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {
    private final JdbcTemplate jdbc;
    private final ResumeTextExtractor extractor;
    public ProfileService(JdbcTemplate jdbc, ResumeTextExtractor extractor) { this.jdbc = jdbc; this.extractor = extractor; }

    public String getProfile() {
        return jdbc.query("SELECT profile_text FROM candidate_profile WHERE id=1", rs -> rs.next() ? rs.getString(1) : null);
    }

    public String refreshFromUploadedResume() throws Exception {
        Path dir = Path.of("data", "resume");
        Path marker = dir.resolve("active-resume-format.txt");
        String extension = Files.exists(marker) ? Files.readString(marker).trim() : "";
        Path selected;
        if (".pdf".equals(extension)) selected = dir.resolve("master-resume.pdf");
        else if (".docx".equals(extension)) selected = dir.resolve("master-resume.docx");
        else {
            Path pdf = dir.resolve("master-resume.pdf");
            Path docx = dir.resolve("master-resume.docx");
            selected = Files.exists(pdf) ? pdf : docx;
        }
        if (!Files.isRegularFile(selected)) throw new IllegalStateException("Upload a PDF or DOCX resume first.");
        String text = extractor.extract(selected);
        jdbc.update("MERGE INTO candidate_profile(id,profile_text,updated_at) KEY(id) VALUES(1,?,CURRENT_TIMESTAMP)", text);
        return text;
    }
}
