package com.example.jobhunter.service;

import com.example.jobhunter.model.Job;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JobRepository {
    private final JdbcTemplate jdbc;
    public JobRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void save(Job j) {
        jdbc.update("MERGE INTO jobs (source,source_id,title,company,location,description,url,apply_url,published_at,workplace_type,salary,match_score) KEY(source,source_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            j.source(), j.sourceId(), j.title(), j.company(), j.location(), j.description(), j.url(), j.applyUrl(), j.publishedAt(), j.workplaceType(), j.salary(), j.matchScore());
    }

    public List<Job> findAll(int min) { return findPage(min, 0, 100).items(); }
    public Page<Job> findPage(int min, int page, int size) {
        int safePage = Math.max(0, page), safeSize = Math.max(1, Math.min(100, size));
        long total = jdbc.queryForObject("SELECT COUNT(*) FROM jobs WHERE match_score >= ?", Long.class, min);
        List<Job> items = jdbc.query("SELECT source,source_id,title,company,location,description,url,apply_url,published_at,workplace_type,salary,match_score FROM jobs WHERE match_score >= ? ORDER BY match_score DESC, first_seen_at DESC LIMIT ? OFFSET ?",
            (rs,n)->new Job(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getInt(12)), min, safeSize, (long)safePage * safeSize);
        return new Page<>(items, total, safePage, safeSize);
    }
    public record Page<T>(List<T> items, long totalElements, int page, int size) {
        public long totalPages() { return totalElements == 0 ? 0 : (totalElements + size - 1) / size; }
    }
}
