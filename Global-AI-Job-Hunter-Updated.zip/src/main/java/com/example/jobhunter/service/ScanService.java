package com.example.jobhunter.service;

import com.example.jobhunter.connector.HttpJobConnectors;
import com.example.jobhunter.model.Job;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScanService {
    private static final Logger log = LoggerFactory.getLogger(ScanService.class);
    private final HttpJobConnectors connectors;
    private final Matcher matcher;
    private final JobRepository repository;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public ScanService(HttpJobConnectors connectors, Matcher matcher, JobRepository repository) {
        this.connectors = connectors; this.matcher = matcher; this.repository = repository;
    }
    @Scheduled(fixedDelayString="${jobhunter.scan-interval-ms:21600000}", initialDelay=10000)
    public void scheduled() { scan(); }

    public String scan() {
        if (!running.compareAndSet(false, true)) return "Scan already running";
        int saved = 0, skipped = 0;
        Map<String,Integer> sourceFailures = new LinkedHashMap<>();
        try {
            Iterable<Job> fetched;
            try { fetched = connectors.fetchAll(); }
            catch (RuntimeException ex) {
                log.error("Job scan failed while fetching connector results", ex);
                return "Scan failed during job discovery. Check application logs for details.";
            }
            if (fetched == null) {
                log.warn("Job scan returned no collection from connectors");
                return "Scan completed with no connector results.";
            }
            for (Job job : fetched) {
                String source = job == null || job.source() == null ? "unknown" : job.source();
                try {
                    if (job == null || blank(job.source()) || blank(job.sourceId()) || blank(job.title()) || !validHttpUrl(job.url())) {
                        skipped++;
                        sourceFailures.merge(source, 1, Integer::sum);
                        log.warn("Skipping invalid job record from source {} (sourceId={})", source, job == null ? "null" : job.sourceId());
                        continue;
                    }
                    Job scored = new Job(job.source(), job.sourceId(), job.title(), job.company(), job.location(), job.description(), job.url(),
                        validOptionalHttpUrl(job.applyUrl()), job.publishedAt(), job.workplaceType(), job.salary(), matcher.score(job));
                    repository.save(scored);
                    saved++;
                } catch (RuntimeException ex) {
                    skipped++;
                    sourceFailures.merge(source, 1, Integer::sum);
                    log.warn("Failed to process job from source {} (sourceId={})", source, job == null ? "null" : job.sourceId(), ex);
                }
            }
            log.info("Job scan completed: saved={}, skipped={}, sourceFailures={}", saved, skipped, sourceFailures);
            return "Scan complete. Jobs saved: " + saved + ", skipped: " + skipped + ", source failures: " + sourceFailures;
        } finally { running.set(false); }
    }
    private boolean blank(String value) { return value == null || value.isBlank(); }
    private boolean validHttpUrl(String value) { return value != null && value.matches("(?i)^https?://[^\\s]+$"); }
    private String validOptionalHttpUrl(String value) { return blank(value) || validHttpUrl(value) ? value : null; }
}
