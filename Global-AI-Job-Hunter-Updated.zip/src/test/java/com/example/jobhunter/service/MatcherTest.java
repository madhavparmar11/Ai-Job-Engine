package com.example.jobhunter.service;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.model.Job;
import org.junit.jupiter.api.Test;

class MatcherTest {
    private Matcher matcher() {
        JobHunterProperties p = new JobHunterProperties();
        p.setKeywords(List.of("java", "spring", "sql"));
        return new Matcher(p);
    }
    private Job job(String title, String description) {
        return new Job("test", "1", title, "Acme", "Remote", description, "https://example.com", "https://example.com", null, "Remote", null, 0);
    }
    @Test void javascriptAloneDoesNotMatchJava() {
        int javascript = matcher().score(job("Frontend Developer", "Build applications with JavaScript and React."));
        int java = matcher().score(job("Java Developer", "Build backend services with Java and Spring Boot."));
        assertTrue(java > javascript);
    }
    @Test void seniorExperienceRequirementReducesScore() {
        Matcher m = matcher();
        int junior = m.score(job("Java Developer", "Java and Spring Boot. 1 year of experience."));
        int senior = m.score(job("Java Developer", "Java and Spring Boot. Required 8 years of experience."));
        assertTrue(junior > senior);
    }
    @Test void preferredExperienceDoesNotTriggerMandatoryPenalty() {
        Matcher m = matcher();
        int preferred = m.score(job("Java Developer", "Java and Spring Boot. 5 years of experience preferred."));
        int unspecified = m.score(job("Java Developer", "Java and Spring Boot."));
        assertEquals(unspecified, preferred);
    }
    @Test void nullFieldsDoNotFail() {
        assertDoesNotThrow(() -> matcher().score(new Job("test", "1", null, null, null, null, null, null, null, null, null, 0)));
    }

    @Test void configuredTargetTitlesIncreaseRelevance() {
        JobHunterProperties p = new JobHunterProperties();
        p.setTargetTitles(List.of("Java Backend Engineer"));
        Matcher configured = new Matcher(p);
        Matcher plain = new Matcher(new JobHunterProperties());
        Job j = job("Java Backend Engineer", "Build Java services.");
        assertTrue(configured.score(j) > plain.score(j));
    }

    @Test void preferredExperienceVariantsDoNotTriggerPenalty() {
        Matcher m = matcher();
        int baseline = m.score(job("Java Developer", "Java and Spring Boot."));
        for (String phrase : List.of("5+ years of experience (preferred)", "5 years of experience would be ideal", "5 years of experience is preferred")) {
            assertEquals(baseline, m.score(job("Java Developer", "Java and Spring Boot. " + phrase)), phrase);
        }
    }

    @Test void experienceRangesAndWordsAreRecognizedAsRequirements() {
        Matcher m = matcher();
        int baseline = m.score(job("Java Developer", "Java and Spring Boot."));
        int range = m.score(job("Java Developer", "Java and Spring Boot. Minimum 3-5 years of experience required."));
        int words = m.score(job("Java Developer", "Java and Spring Boot. Three years of relevant experience required."));
        assertTrue(range < baseline);
        assertTrue(words < baseline);
    }

    @Test void configuredLocationPreferencePenalizesKnownMismatchOnly() {
        JobHunterProperties p = new JobHunterProperties();
        p.setPreferredLocations(List.of("India"));
        Matcher m = new Matcher(p);
        int india = m.score(new Job("x","1","Java Developer","A","India","Java Spring Boot", "https://example.com",null,null,"On-site",null,0));
        int us = m.score(new Job("x","2","Java Developer","A","United States","Java Spring Boot", "https://example.com",null,null,"On-site",null,0));
        assertTrue(india > us);
    }
}
