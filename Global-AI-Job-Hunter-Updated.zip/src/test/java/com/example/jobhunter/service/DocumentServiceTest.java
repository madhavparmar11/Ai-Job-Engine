package com.example.jobhunter.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;

class DocumentServiceTest {
    @Test void rejectsTraversalBeforeCallingAi() {
        OpenAiService ai = mock(OpenAiService.class);
        DocumentService service = new DocumentService(ai);
        assertThrows(IllegalArgumentException.class,
                () -> service.createTailoredResume("../outside", "job1", "profile", "description"));
        verifyNoInteractions(ai);
    }
    @Test void rejectsDotSegmentsInIdentifiers() {
        OpenAiService ai = mock(OpenAiService.class);
        DocumentService service = new DocumentService(ai);
        assertThrows(IllegalArgumentException.class,
                () -> service.createCoverLetter("greenhouse", "..", "profile", "description"));
        verifyNoInteractions(ai);
    }
}
