package com.example.jobhunter.service;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import com.example.jobhunter.connector.HttpJobConnectors;
import com.example.jobhunter.model.Job;
import java.util.List;
import org.junit.jupiter.api.Test;

class ScanServiceTest {
    @Test void invalidJobDoesNotStopScan() {
        HttpJobConnectors connectors = mock(HttpJobConnectors.class);
        Matcher matcher = mock(Matcher.class);
        JobRepository repository = mock(JobRepository.class);
        when(connectors.fetchAll()).thenReturn(List.of(
            new Job("rss", "", "Bad job", "Acme", "Remote", "", "https://example.com", null, null, null, null, 0),
            new Job("rss", "good-1", "Java Developer", "Acme", "Remote", "Java", "https://example.com/job", "https://example.com/apply", null, "Remote", null, 0)));
        when(matcher.score(any())).thenReturn(70);
        ScanService service = new ScanService(connectors, matcher, repository);
        String result = service.scan();
        assertTrue(result.contains("Jobs saved: 1, skipped: 1"));
        verify(repository, times(1)).save(any());
    }

    @Test void onePersistenceFailureDoesNotStopFollowingJobs() {
        HttpJobConnectors connectors = mock(HttpJobConnectors.class);
        Matcher matcher = mock(Matcher.class);
        JobRepository repository = mock(JobRepository.class);
        Job first = new Job("rss", "one", "First", "Acme", "Remote", "", "https://example.com/1", null, null, null, null, 0);
        Job second = new Job("rss", "two", "Second", "Acme", "Remote", "", "https://example.com/2", null, null, null, null, 0);
        when(connectors.fetchAll()).thenReturn(List.of(first, second));
        when(matcher.score(any())).thenReturn(60);
        doThrow(new RuntimeException("database failure")).doNothing().when(repository).save(any());
        String result = new ScanService(connectors, matcher, repository).scan();
        assertTrue(result.contains("Jobs saved: 1, skipped: 1"));
        verify(repository, times(2)).save(any());
    }
}
