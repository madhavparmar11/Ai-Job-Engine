package com.example.jobhunter.service;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ResumeTextExtractorTest {
    @TempDir Path temp;
    @Test void extractsParagraphAndTableCellText() throws Exception {
        Path file = temp.resolve("resume.docx");
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText("Candidate Name");
            var table = doc.createTable(1, 1);
            table.getRow(0).getCell(0).setText("Java and Spring Boot");
            try (var out = Files.newOutputStream(file)) { doc.write(out); }
        }
        String text = new ResumeTextExtractor().extract(file);
        assertTrue(text.contains("Candidate Name"));
        assertTrue(text.contains("Java and Spring Boot"));
    }
    @Test void rejectsEmptyOrUnreadableDocument() throws Exception {
        Path file = temp.resolve("empty.docx");
        try (XWPFDocument doc = new XWPFDocument(); var out = Files.newOutputStream(file)) { doc.write(out); }
        assertThrows(IllegalArgumentException.class, () -> new ResumeTextExtractor().extract(file));
    }
}
