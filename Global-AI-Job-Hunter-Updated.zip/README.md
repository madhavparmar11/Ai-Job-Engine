# Ai-Job-Engine
Ai

## Security and reliability notes

- Keep this personal dashboard behind a trusted network or reverse-proxy authentication. The current source does not yet implement application-user authentication/authorization; do not expose it directly to the public internet.
- Generated document identifiers are restricted to safe path segments, and downloads resolve a generated document by source, job ID, and document type rather than accepting an arbitrary filesystem path.
- Resume uploads are size/type checked, parsed before replacing the active resume, and the active format is recorded explicitly. DOCX extraction includes table-cell text.
- External job listing links are restricted in the dashboard to HTTP and HTTPS. Tracking actions no longer interpolate feed-provided identifiers into inline JavaScript.


## Security note (important)

HTTP Basic authentication is enabled for all routes except `/api/health`. Spring Boot creates a development user and logs a one-time password at startup when no custom user credentials are configured. Check the startup logs and do not expose the application publicly until you configure a strong `SPRING_SECURITY_USER_NAME` and `SPRING_SECURITY_USER_PASSWORD` through your deployment environment/secrets manager. HTTPS is required outside localhost. CSRF protection is enabled using a readable CSRF cookie/token for the dashboard API calls.


### Matching and pagination

Configure `jobhunter.target-titles` and `jobhunter.preferred-locations` in `application.yml`. Job and application endpoints are paginated (zero-based pages, maximum 100 records per page). Review remote job location restrictions manually; a generic remote label does not mean worldwide eligibility.
