# Operating the automation

## Environment variables
- `OPENAI_API_KEY`: server-side OpenAI API key. Never put it in browser JavaScript or commit it.
- `OPENAI_MODEL`: model name available to your API project.
- `AI_ENABLED`: reserved feature switch; AI endpoints require a configured key.
- `AUTO_GENERATE_DOCUMENTS`: document-generation scheduling flag (generation is still review-only).
- `MAIL_ENABLED`, `MAIL_FROM`: optional notification configuration; SMTP host/credentials must also be configured if email is enabled.

## AI endpoints
- `GET /api/ai/status`
- `POST /api/ai/profile/refresh` — extract text from uploaded master resume into local profile storage.
- `POST /api/ai/documents/resume` — JSON body: `source`, `sourceId`, `jobDescription`.
- `POST /api/ai/documents/cover-letter` — same body.
- `GET /api/files/download?path=<returned-file-path>` — download generated DOCX.

## Automation boundaries
The six-hour scheduler runs in the Spring Boot process. It only runs while the app is deployed and running. For reliable production operation, deploy it on an always-on host and use persistent storage/database backups. Add monitoring, retry/backoff, source-specific rate limits, secrets management, authentication and HTTPS before exposing it publicly.

Resume extraction is not equivalent to verified profile creation: inspect extracted text and correct it. AI-generated content must be reviewed. This project does not autonomously submit applications or bypass platform restrictions.

## Job matching and result pagination

- `jobhunter.target-titles` contributes a relevance bonus when a configured target title appears in a job title.
- `jobhunter.preferred-locations` applies a modest penalty to known, non-remote locations outside the configured list. A generic `Remote` location is treated as unknown rather than proof of worldwide eligibility. Review each employer's geographic restrictions before applying.
- `GET /api/jobs?page=0&size=25&minScore=60` and `GET /api/applications?page=0&size=25` return paginated results. Page numbering starts at zero; page size is capped at 100.
- Scan failures are logged with source and job identifiers where available. The scan response includes per-source skipped/failure counts.
