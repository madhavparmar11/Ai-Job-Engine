# Global AI Job Hunter — integrated Java automation MVP

Java 21 + Spring Boot application. LinkedIn-independent.

## Included in this single project
- Scheduled job discovery every six hours while the app is running.
- Greenhouse, Lever and Ashby employer-board connectors.
- Remotive, Remote OK and RSS connectors.
- Common job model, H2 persistence, de-duplication and baseline keyword/title scoring.
- Browser dashboard to run scans, view jobs and save jobs to an application tracker.
- PDF/DOCX resume upload and text extraction.
- Candidate profile text storage.
- OpenAI Responses API adapter for tailored resume and cover-letter drafting.
- Editable DOCX generation and download endpoint.
- Application approval boundary: documents are generated for review; no automatic application submission.

## Run
Requirements: JDK 21+ and Maven 3.9+.
```bash
mvn spring-boot:run
```
Open `http://localhost:8080`.

## Configure
Edit `src/main/resources/application.yml` to set your target job titles, skills and ATS employer-board identifiers:
- Greenhouse board token: employer's Greenhouse hosted-board identifier.
- Lever site slug: `jobs.lever.co/<slug>`.
- Ashby board name: `jobs.ashbyhq.com/<board>`.

Set `OPENAI_API_KEY` as a server environment variable to enable AI document endpoints. Optionally set `OPENAI_MODEL`. Never put API keys in frontend code or commit them.

## Main endpoints
- `GET /api/health`
- `POST /api/scan`
- `GET /api/jobs?minScore=70`
- `POST /api/resume/upload` (multipart field `file`, PDF/DOCX)
- `POST /api/ai/profile/refresh`
- `GET /api/ai/status`
- `POST /api/ai/documents/resume`
- `POST /api/ai/documents/cover-letter`
- `GET /api/files/download?path=<generated path>`
- `GET /api/applications`
- `POST /api/applications`

## Important production work still required
This is an integrated MVP foundation, not a certified production-ready autonomous recruiter. ATS public endpoints are generally per-employer, so populate and maintain the board registry. Some listed job platforms do not expose free public APIs; integrate only via official, licensed or otherwise permitted access. Check each source's current terms, rate limits and attribution rules.

The current matching algorithm is a transparent baseline, not a validated semantic ranking system. Resume text extraction does not automatically create a verified profile; inspect and correct it. AI-generated documents must be reviewed for factual accuracy. Application submission remains manual/approval-based; public job APIs do not automatically authorize submission.

Before exposing this app publicly, add authentication, HTTPS, CSRF protection, secrets management, rate limiting, retry/backoff, observability, persistent production storage, backups, and tests. The six-hour scheduler runs only while this Spring Boot process is running on an always-on host.
