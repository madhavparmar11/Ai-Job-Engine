package com.example.jobhunter.web;
import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.service.*;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api")
public class JobController {
 private final JobRepository repo; private final ScanService scan; private final JobHunterProperties p;
 public JobController(JobRepository r,ScanService s,JobHunterProperties p){repo=r;scan=s;this.p=p;}
 @GetMapping("/health") public String health(){return "Global AI Job Hunter is running";}
 @PostMapping("/scan") public String scan(){return scan.scan();}
 @GetMapping("/jobs") public Object jobs(@RequestParam(defaultValue="-1") int minScore){return repo.findAll(minScore<0?p.getMinMatchScore():minScore);}
}