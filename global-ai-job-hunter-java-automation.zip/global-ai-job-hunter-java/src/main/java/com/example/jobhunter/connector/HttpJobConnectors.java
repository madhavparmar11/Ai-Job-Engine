package com.example.jobhunter.connector;
import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.model.Job;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import org.jsoup.Jsoup;
import org.springframework.stereotype.Component;
import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.io.XmlReader;
@Component
public class HttpJobConnectors {
 private final JobHunterProperties p; private final ObjectMapper mapper=new ObjectMapper();
 private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
 public HttpJobConnectors(JobHunterProperties p){this.p=p;}
 private JsonNode json(String u)throws Exception{
  var req=HttpRequest.newBuilder(URI.create(u)).timeout(Duration.ofSeconds(30)).header("User-Agent","GlobalAIJobHunter/0.1 personal discovery").GET().build();
  var res=client.send(req,HttpResponse.BodyHandlers.ofString());
  if(res.statusCode()/100!=2)throw new IllegalStateException("HTTP "+res.statusCode());
  return mapper.readTree(res.body());
 }
 private String clean(String s){return Jsoup.parse(s==null?"":s).text();}
 public List<Job> fetchAll(){
  List<Job> out=new ArrayList<>();
  for(String b:p.getGreenhouseBoards())try{
   for(JsonNode j:json("https://boards-api.greenhouse.io/v1/boards/"+b+"/jobs?content=true").path("jobs")){
    String link=j.path("absolute_url").asText();
    out.add(new Job("greenhouse",j.path("id").asText(),j.path("title").asText(),b,j.path("location").path("name").asText(),clean(j.path("content").asText()),link,link,j.path("updated_at").asText(),null,null,0));
   }
  }catch(Exception e){System.err.println("Greenhouse "+b+": "+e.getMessage());}
  for(String site:p.getLeverSites())try{
   for(JsonNode j:json("https://api.lever.co/v0/postings/"+site+"?mode=json")){
    JsonNode c=j.path("categories"); String link=j.path("hostedUrl").asText();
    out.add(new Job("lever",j.path("id").asText(),j.path("text").asText(),site,c.path("location").asText(),clean(j.path("descriptionPlain").asText()),link,j.path("applyUrl").asText(link),j.path("createdAt").asText(),c.path("workplaceType").asText(),null,0));
   }
  }catch(Exception e){System.err.println("Lever "+site+": "+e.getMessage());}
  for(String board:p.getAshbyBoards())try{
   for(JsonNode j:json("https://api.ashbyhq.com/posting-api/job-board/"+board+"?includeCompensation=true").path("jobs")){
    String link=j.path("jobUrl").asText();
    out.add(new Job("ashby",link,j.path("title").asText(),board,j.path("location").asText(),clean(j.path("descriptionPlain").asText()),link,j.path("applyUrl").asText(),j.path("publishedAt").asText(),j.path("workplaceType").asText(),j.path("compensation").path("scrapeableCompensationSalarySummary").asText(),0));
   }
  }catch(Exception e){System.err.println("Ashby "+board+": "+e.getMessage());}
  if(p.isEnableRemotive())try{
   for(JsonNode j:json("https://remotive.com/api/remote-jobs").path("jobs")){
    String link=j.path("url").asText();
    out.add(new Job("remotive",j.path("id").asText(),j.path("title").asText(),j.path("company_name").asText(),j.path("candidate_required_location").asText(),clean(j.path("description").asText()),link,link,j.path("publication_date").asText(),"Remote",j.path("salary").asText(),0));
   }
  }catch(Exception e){System.err.println("Remotive: "+e.getMessage());}
  if(p.isEnableRemoteok())try{
   for(JsonNode j:json("https://remoteok.com/api"))if(j.has("id")&&j.has("position")){
    String link=j.path("url").asText();
    out.add(new Job("remoteok",j.path("id").asText(),j.path("position").asText(),j.path("company").asText(),j.path("location").asText(),clean(j.path("description").asText()),link,j.path("apply_url").asText(link),j.path("date").asText(),"Remote",null,0));
   }
  }catch(Exception e){System.err.println("RemoteOK: "+e.getMessage());}
  for(String feed:p.getRssFeeds())try{
   var f=new SyndFeedInput().build(new XmlReader(URI.create(feed).toURL()));
   for(var e:f.getEntries()){
    String link=e.getLink();
    out.add(new Job("rss:"+feed,e.getUri()!=null?e.getUri():link,e.getTitle(),"RSS listing","",clean(e.getDescription()==null?"":e.getDescription().getValue()),link,link,e.getPublishedDate()==null?null:e.getPublishedDate().toInstant().toString(),null,null,0));
   }
  }catch(Exception e){System.err.println("RSS "+feed+": "+e.getMessage());}
  return out;
 }
}