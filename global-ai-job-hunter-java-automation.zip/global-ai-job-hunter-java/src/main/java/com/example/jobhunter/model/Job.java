package com.example.jobhunter.model;
public record Job(String source, String sourceId, String title, String company, String location,
 String description, String url, String applyUrl, String publishedAt, String workplaceType,
 String salary, int matchScore) {}