package com.example.jobhunter.service;
import com.example.jobhunter.model.ApplicationRecord;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class ApplicationRepository {
 private final JdbcTemplate jdbc;
 public ApplicationRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
 public void save(String source,String sourceId,String title,String status){
  jdbc.update("MERGE INTO applications(source,source_id,title,status) KEY(source,source_id) VALUES(?,?,?,?)",source,sourceId,title,status);
 }
 public List<ApplicationRecord> all(){
  return jdbc.query("SELECT id,source,source_id,title,status,notes,CAST(created_at AS VARCHAR) FROM applications ORDER BY created_at DESC",
   (r,n)->new ApplicationRecord(r.getLong(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getString(7)));
 }
}