package com.example.jobhunter.web;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class DashboardController {
 @GetMapping("/") public String home(){return "index";}
}