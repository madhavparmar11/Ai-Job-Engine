package com.example.jobhunter.service;
import java.io.InputStream;
import java.nio.file.*;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.stereotype.Service;
@Service
public class ResumeTextExtractor {
 public String extract(Path path) throws Exception {
  String n=path.getFileName().toString().toLowerCase();
  if(n.endsWith(".pdf")) try(var doc=Loader.loadPDF(path.toFile())) { return new PDFTextStripper().getText(doc); }
  if(n.endsWith(".docx")) try(InputStream in=Files.newInputStream(path); XWPFDocument doc=new XWPFDocument(in)) {
   StringBuilder b=new StringBuilder(); doc.getParagraphs().forEach(p->b.append(p.getText()).append('\n')); return b.toString();
  }
  throw new IllegalArgumentException("Unsupported resume format");
 }
}