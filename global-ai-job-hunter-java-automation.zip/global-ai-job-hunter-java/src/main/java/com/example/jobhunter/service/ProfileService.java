package com.example.jobhunter.service;
import java.nio.file.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class ProfileService {
 private final JdbcTemplate jdbc; private final ResumeTextExtractor extractor;
 public ProfileService(JdbcTemplate jdbc,ResumeTextExtractor extractor){this.jdbc=jdbc;this.extractor=extractor;}
 public String getProfile(){
  return jdbc.query("SELECT profile_text FROM candidate_profile WHERE id=1",
   rs->rs.next()?rs.getString(1):null);
 }
 public String refreshFromUploadedResume() throws Exception {
  Path pdf=Path.of("data/resume/master-resume.pdf"), docx=Path.of("data/resume/master-resume.docx");
  Path selected=Files.exists(pdf)?pdf:docx;
  if(!Files.exists(selected)) throw new IllegalStateException("Upload a PDF or DOCX resume first.");
  String text=extractor.extract(selected);
  jdbc.update("MERGE INTO candidate_profile(id,profile_text,updated_at) KEY(id) VALUES(1,?,CURRENT_TIMESTAMP)",text);
  return text;
 }
}
