package com.example.jobhunter.web;
import java.io.IOException;
import java.nio.file.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.example.jobhunter.service.ResumeTextExtractor;
@RestController
@RequestMapping("/api/resume")
public class ResumeController {
 private final ResumeTextExtractor extractor;
 public ResumeController(ResumeTextExtractor extractor){this.extractor=extractor;}
 @PostMapping(value="/upload", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
 public String upload(@RequestParam("file") MultipartFile file) throws Exception {
  String name=file.getOriginalFilename()==null?"resume":file.getOriginalFilename().toLowerCase();
  if(!(name.endsWith(".pdf")||name.endsWith(".docx"))) throw new IllegalArgumentException("Upload a PDF or DOCX file.");
  if(file.getSize()>10*1024*1024) throw new IllegalArgumentException("Maximum resume size is 10 MB.");
  Path dir=Path.of("data","resume"); Files.createDirectories(dir);
  Path path=dir.resolve(name.endsWith(".pdf")?"master-resume.pdf":"master-resume.docx");
  Files.copy(file.getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
  String text=extractor.extract(path);
  Files.writeString(dir.resolve("master-resume-extracted.txt"),text);
  return "Resume uploaded and text extracted. Please verify the extracted profile before using it for tailoring.";
 }
}