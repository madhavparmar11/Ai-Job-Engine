package com.example.jobhunter.service;
import com.example.jobhunter.config.JobHunterProperties;
import com.example.jobhunter.model.Job;
import org.springframework.stereotype.Component;
@Component
public class Matcher {
 private final JobHunterProperties p;
 public Matcher(JobHunterProperties p){this.p=p;}
 public int score(Job j){
  String text=(s(j.title())+" "+s(j.description())+" "+s(j.location())).toLowerCase();
  long hits=p.getKeywords().stream().filter(k->text.contains(k.toLowerCase())).count();
  double keyword=65.0*hits/Math.max(1,p.getKeywords().size());
  boolean title=p.getTargetTitles().stream().anyMatch(t->s(j.title()).toLowerCase().contains(t.toLowerCase()));
  boolean remote=text.contains("remote") || "remote".equalsIgnoreCase(j.workplaceType());
  return (int)Math.min(100,Math.round(keyword+(title?25:0)+(remote?10:0)));
 }
 private String s(String x){return x==null?"":x;}
}