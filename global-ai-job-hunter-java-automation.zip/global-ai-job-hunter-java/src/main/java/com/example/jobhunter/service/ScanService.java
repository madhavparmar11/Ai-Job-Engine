package com.example.jobhunter.service;
import com.example.jobhunter.connector.HttpJobConnectors;
import com.example.jobhunter.model.Job;
import java.util.concurrent.atomic.AtomicBoolean;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;
@Service
public class ScanService {
 private final HttpJobConnectors c; private final Matcher m; private final JobRepository r;
 private final AtomicBoolean running=new AtomicBoolean(false);
 public ScanService(HttpJobConnectors c,Matcher m,JobRepository r){this.c=c;this.m=m;this.r=r;}
 @Scheduled(fixedDelayString="${jobhunter.scan-interval-ms:21600000}",initialDelay=10000)
 public void scheduled(){scan();}
 public String scan(){
  if(!running.compareAndSet(false,true))return "Scan already running";
  int n=0; try{for(Job j:c.fetchAll()){
   Job x=new Job(j.source(),j.sourceId(),j.title(),j.company(),j.location(),j.description(),j.url(),j.applyUrl(),j.publishedAt(),j.workplaceType(),j.salary(),m.score(j));
   r.save(x); n++;
  }return "Scan complete. Jobs processed: "+n;
  }finally{running.set(false);}
 }
}