package com.example.jobhunter.model;
public record ApplicationRecord(Long id,String source,String sourceId,String title,String status,String notes,String createdAt) {}