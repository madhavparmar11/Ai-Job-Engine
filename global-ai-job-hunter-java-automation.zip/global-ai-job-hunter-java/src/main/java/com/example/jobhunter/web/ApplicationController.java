package com.example.jobhunter.web;
import com.example.jobhunter.service.ApplicationRepository;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/applications")
public class ApplicationController {
 private final ApplicationRepository repo;
 public ApplicationController(ApplicationRepository r){repo=r;}
 @GetMapping public Object all(){return repo.all();}
 @PostMapping public String save(@RequestBody Map<String,String> body){
  String source=body.get("source"), id=body.get("sourceId");
  if(source==null||id==null||source.isBlank()||id.isBlank()) throw new IllegalArgumentException("source and sourceId are required");
  repo.save(source,id,body.getOrDefault("title",id),body.getOrDefault("status","SAVED"));
  return "Job added to application tracker.";
 }
}