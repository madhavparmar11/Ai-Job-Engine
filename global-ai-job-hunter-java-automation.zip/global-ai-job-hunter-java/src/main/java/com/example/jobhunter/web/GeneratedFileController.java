package com.example.jobhunter.web;
import java.nio.file.*;
import org.springframework.core.io.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/files")
public class GeneratedFileController {
 @GetMapping("/download") public ResponseEntity<Resource> download(@RequestParam String path)throws Exception{
  Path root=Path.of("data","generated").toAbsolutePath().normalize();
  Path file=Path.of(path).toAbsolutePath().normalize();
  if(!file.startsWith(root)||!Files.isRegularFile(file)) return ResponseEntity.notFound().build();
  return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
   .header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\""+file.getFileName()+"\"")
   .body(new FileSystemResource(file));
 }
}
