package com.example.jobhunter.service;
import java.nio.file.*;
import java.util.*;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.stereotype.Service;

/** Creates editable DOCX documents. All claims must be grounded in the supplied verified profile. */
@Service
public class DocumentService {
 private final OpenAiService ai;
 public DocumentService(OpenAiService ai){this.ai=ai;}
 public Path createTailoredResume(String source,String sourceId,String profile,String jobDescription) throws Exception {
  String content=ai.generate(
   "You are a careful resume editor. Rewrite a targeted resume using ONLY facts explicitly present in the candidate profile. Never invent employers, dates, titles, skills, metrics, certifications, education or achievements. Preserve factual meaning. Use ATS-friendly headings and concise bullets. Return plain text only.",
   "VERIFIED CANDIDATE PROFILE:\n"+profile+"\n\nJOB DESCRIPTION:\n"+jobDescription+
   "\n\nProduce a tailored resume. Emphasize relevant verified evidence and omit unsupported requirements.");
  return writeDocx("tailored-resume",source,sourceId,content);
 }
 public Path createCoverLetter(String source,String sourceId,String profile,String jobDescription) throws Exception {
  String content=ai.generate(
   "Write a concise professional cover letter based only on the verified candidate profile. Do not invent experience or claim skills not evidenced. Return plain text only.",
   "CANDIDATE PROFILE:\n"+profile+"\n\nJOB DESCRIPTION:\n"+jobDescription);
  return writeDocx("cover-letter",source,sourceId,content);
 }
 private Path writeDocx(String type,String source,String sourceId,String text) throws Exception {
  Path dir=Path.of("data","generated",safe(source),safe(sourceId)); Files.createDirectories(dir);
  Path path=dir.resolve(type+".docx");
  try(XWPFDocument doc=new XWPFDocument()){
   for(String line:text.split("\\R")){
    XWPFParagraph p=doc.createParagraph();
    p.createRun().setText(line);
   }
   try(var out=Files.newOutputStream(path)){doc.write(out);}
  }
  return path;
 }
 private String safe(String x){return (x==null?"unknown":x).replaceAll("[^A-Za-z0-9._-]","_");}
}
